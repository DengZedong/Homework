import re

#病人类
class patient:
    def __init__(self):
        self.name = '姓名缺省'
        self.id = 'ID缺省'
        self.sex = '男'
        self.age = 30
        self.height = 165
        self.weight = 65
        self.atrial_parameters = [0]*2
        self.ventricular_parameters = [0] * 2
        self.left_ventricular_parameters = [0.0] *6
        self.wall_array = [0] *17
        self.raw_text = '' #未处理的[所见]文本
        self.conclusion = '阴性'
        self.conclusion_text = '' #未处理的结论文本
        self.invalid_temp = False

    #左心室舒张末期室壁厚度处理
    def wall_thickness_progress(self,old_temp):
        paras = self.raw_text.split('\n')
        flag = False
        wall_array = []
        _old_array = []
        for p in paras:
            if flag:
               # if '，' in p:
                 #   old_temp = True
                if not old_temp:
                   ps = p.split(' ')  #新模板的分隔符
                   for i in ps:
                     if 'mm' in i:
                        out = int(re.findall("""(.*)mm""",i)[0])
                        wall_array.append(out)
                else:
                    out = re.findall(r'\d+',p)
                    tranf = [int(out[i]) for i in range(0,len(out))]
                   # print(tranf)
                    _old_array = _old_array + tranf
                   # print(_old_array)
                    wall_array = tranf + wall_array
            if '左心室舒张末期室壁厚度（mm）：' in p:
                flag = True
        if wall_array[0] == 0:
            wall_array = []
        if len(wall_array) == 17:
            self.wall_array = wall_array

    def process_report(self,report,old_temp):  #所见报告文本处理
        self.name = report['姓名']
        self.sex = report['性别']
        self.age = report['年龄']
        self.conclusion_text = report['结论']
        self.raw_text = report['所见']
       # print(self.raw_text)
        height_match = re.findall("""身高：(.*)cm""",report['所见'])   #匹配身高
        if height_match:
            self.height = height_match[0]
        weight_match = re.findall("""体重：(.*)kg""",report['所见'])   #匹配体重
        if weight_match:
            self.weight = weight_match[0]

        atrial_parameters = [0,0]
        ventricular_parameters = [0,0]
        texts = re.findall("""左心房(.*?)㎝""",report['所见'])
        if texts:
            nums = re.findall(r'\d+', texts[0])
            if nums:
                atrial_parameters[0] = int(nums[0])

        texts = re.findall("""右心房(.*?)㎝""",report['所见'])
        if texts:
            tmp_text = texts[0]  #右心房
            nums = re.findall(r'\d+', tmp_text)
            if nums:
                atrial_parameters[1] = int(nums[0])
        self.atrial_parameters = atrial_parameters

        texts = re.findall("""左心室(.*?)mm""",report['所见'])
        if texts:
            tmp_text = texts[0]  #左心室
            nums = re.findall(r'\d+', tmp_text)
            if nums:
                ventricular_parameters[0] = int(nums[0])

        texts = re.findall("""右心室(.*?)mm""",report['所见'])
        if texts:
            tmp_text = texts[0]  #右心室
            nums = re.findall(r'\d+', tmp_text)
            if nums:
                ventricular_parameters[1] = int(nums[0])
        self.ventricular_parameters = ventricular_parameters

        left_ventricular_parameters = [0.0] * 6
        texts = re.findall("""EF：(.*?)%""",report['所见'])
        left_ventricular_parameters[0] = float(texts[0])
        texts = re.findall("""EDV：(.*?)ml""",report['所见'])
        left_ventricular_parameters[1] = float(texts[0])
        texts = re.findall("""ESV：(.*?)ml""",report['所见'])
        left_ventricular_parameters[2] = float(texts[0])
        texts = re.findall("""SV：(.*?)ml""",report['所见'])
        left_ventricular_parameters[3] = float(texts[0])
        texts = re.findall("""CO：(.*?)L/min""",report['所见'])
        left_ventricular_parameters[4] = float(texts[0])
        texts = re.findall("""HR：(.*?)/min""",report['所见'])
        left_ventricular_parameters[5] = float(texts[0])
        self.left_ventricular_parameters = left_ventricular_parameters
        self.wall_thickness_progress(old_temp)



