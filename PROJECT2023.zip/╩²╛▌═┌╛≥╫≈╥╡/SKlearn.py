from sklearn import svm
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn import datasets
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn import datasets
from sklearn import metrics
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import f1_score
from sklearn.metrics import recall_score


def SVM_train(x_array,y_array,x_array_verify,y_array_verify):
  # 划分训练集和测试集
  x_train, x_test, y_train, y_test = x_array,x_array_verify,y_array,y_array_verify

  # 创建SVM分类器
  clf = svm.SVC(kernel='linear')

  # 训练模型
  clf.fit(x_train, y_train)

  # 预测测试集结果
  y_pred = clf.predict(x_test)

  # 输出准确率
  _accuracy = clf.score(x_test, y_test)
  print("----------------------------------")
  print('[SVM准确率]:', clf.score(x_test, y_test))
  #计算AUC值
  auc = roc_auc_score(y_test, y_pred)
  print('[SVM AUC值]:', auc)
  #计算F1-Score
  f1 = f1_score(y_test, y_pred, average='weighted')
  print('[SVM F1 score]: ', f1)
  #计算召回率
  recall = recall_score(y_test,y_pred)
  print('[SVM召回率]:', recall)
  print("----------------------------------")
  # 计算ROC曲线
  fpr, tpr, thresholds = metrics.roc_curve(y_test, y_pred)
  # 绘制ROC曲线
  plt.plot(fpr, tpr)
  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.title('SVM ROC Curve')
  plt.show()

  return _accuracy,auc,f1,recall

def Logistic_train(x_array,y_array,x_array_verify,y_array_verify):
  # 划分训练集和测试集
  x_train, x_test, y_train, y_test = x_array,x_array_verify,y_array,y_array_verify
 # print("训练集数据量："+str(len(x_train)))
 # print("测试集数据量：" + str(len(x_test)))
  # 创建逻辑回归模型并训练
  lr = LogisticRegression()
  lr.fit(x_train, y_train)

  # 在测试集上进行预测并计算准确率
  y_pred = lr.predict(x_test)
  auc = roc_auc_score(y_test, y_pred)
  # 计算ROC曲线
  fpr, tpr, thresholds = metrics.roc_curve(y_test, y_pred)
  # 绘制ROC曲线
  plt.plot(fpr, tpr)
  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.title('Logistic ROC Curve')
  plt.show()
  print("----------------------------------")
  accuracy = lr.score(x_test, y_test)
  print('[Logistic回归准确率]:', accuracy)
  print('[Logistic回归AUC值]:', auc)
  f1 = f1_score(y_test, y_pred, average='weighted')
  print('[Logistic回归 F1 score]: ', f1)
  #计算召回率
  recall = recall_score(y_test, y_pred)
  print('[Logistic回归召回率]:', recall)
  print("----------------------------------")
  return accuracy, auc, f1, recall

def KNN_train(x_array,y_array,x_array_verify,y_array_verify):
  # 划分训练集和测试集
  x_train, x_test, y_train, y_test = x_array, x_array_verify, y_array, y_array_verify
 # print("训练集数据量："+str(len(x_train)))
 # print("测试集数据量：" + str(len(x_test)))
  # 初始化KNN分类器，设置邻居数量为3
  knn = KNeighborsClassifier(n_neighbors=3)

  # 拟合模型
  knn.fit(x_train, y_train)

  # 预测测试集
  y_pred = knn.predict(x_test)
  auc = roc_auc_score(y_test, y_pred)
  # 计算ROC曲线
  fpr, tpr, thresholds = metrics.roc_curve(y_test, y_pred)
  # 绘制ROC曲线
  plt.plot(fpr, tpr)
  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.title('KNN ROC Curve')
  plt.show()
  # 输出准确率
  accuracy = knn.score(x_test, y_test)
  print("----------------------------------")
  print("[KNN准确率]:",accuracy)
  print("[KNN AUC值]:", auc)
  f1 = f1_score(y_test, y_pred, average='weighted')
  print('[KNN F1 score]: ', f1)
  #计算召回率
  recall = recall_score(y_test, y_pred)
  print('[KNN召回率]:', recall)
  print("----------------------------------")
  return accuracy, auc, f1, recall

def RandomForest_train(x_array,y_array,x_array_verify,y_array_verify):

  # 划分训练集和测试集
  x_train, x_test, y_train, y_test = x_array, x_array_verify, y_array, y_array_verify
 # print("训练集数据量："+str(len(x_train)))
#  print("测试集数据量：" + str(len(x_test)))
  # 初始化随机森林分类器，设置树的数量为100
  rf = RandomForestClassifier(n_estimators=100)

  # 拟合模型
  rf.fit(x_train, y_train)

  # 预测测试集
  y_pred = rf.predict(x_test)
  _accuracy = rf.score(x_test, y_test)
  print("----------------------------------")
  # 输出准确率
  print('[随机森林回归准确率]:', _accuracy)
  auc = roc_auc_score(y_test, y_pred)
  print('[随机森林AUC值]:', auc)
  # 计算ROC曲线
  fpr, tpr, thresholds = metrics.roc_curve(y_test, y_pred)
  # 绘制ROC曲线
  plt.plot(fpr, tpr)
  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.title('Random Forest ROC Curve')
  plt.show()
  f1 = f1_score(y_test, y_pred, average='weighted')
  print('[随机森林 F1 score]: ', f1)
  #计算召回率
  recall = recall_score(y_test, y_pred)
  print('[随机森林召回率]:', recall)
  print("----------------------------------")
  return _accuracy, auc, f1, recall

def NB_train(x_array,y_array,x_array_verify,y_array_verify):
  # 将数据集划分为训练集和测试集
  x_train, x_test, y_train, y_test = x_array, x_array_verify, y_array, y_array_verify

  # 创建GaussianNB分类器
  gnb = GaussianNB()

  # 使用训练数据拟合模型
  gnb.fit(x_train, y_train)

  # 使用测试数据进行预测
  y_pred = gnb.predict(x_test)
  auc = roc_auc_score(y_test, y_pred)
  print("----------------------------------")
  # 输出预测结果和准确率
  print("[朴素贝叶斯AUC值]:", auc)
  _accuracy = gnb.score(x_test, y_test)
  print("[朴素贝叶斯准确率]:",_accuracy)
  f1 = f1_score(y_test, y_pred, average='weighted')
  print('[朴素贝叶斯 F1 score]: ', f1)
  #计算召回率
  recall = recall_score(y_test, y_pred)
  print('[朴素贝叶斯召回率]:', recall)
  print("----------------------------------")
  # 计算ROC曲线
  fpr, tpr, thresholds = metrics.roc_curve(y_test, y_pred)
  # 绘制ROC曲线
  plt.plot(fpr, tpr)
  plt.xlabel('False Positive Rate')
  plt.ylabel('True Positive Rate')
  plt.title('Naive Bayes ROC Curve')
  plt.show()

  return _accuracy, auc, f1, recall