import numpy as np
import pygame
import pygame.gfxdraw
import statistics as sts

def draw_background(screen):
    screen.fill((255,255, 255))
    screen.fill((16,15,29))
def draw_note(screen):
    image_surface = pygame.image.load("UI/注释.png")
    screen.blit(image_surface, (249, 10))
def clear_figure(screen):
    draw_background(screen)

def draw_figure(data,screen,x,y):
    PX, PY, PW, PH = x,y, 257, 200
    DPOIARRAY = [[0, 0], [-65,8], [-65, 61], [0, 106], [29, 60],
                 [27, 6], [15, 28], [-33, 32], [-33, 71], [14, 105],
                 [33,73], [33,35], [18, 56], [3, 72], [19, 106],
                 [51, 73], [34, 86]]

    NORMAL = 8
    ratio = [( data[i] - NORMAL ) * 1.0 / NORMAL for i in range(0,16)]
    ratio.append(( data[16] -4) * 1.0 /4)
    for i in range(0,17):
        _dx = DPOIARRAY[i][0]
        _dy = DPOIARRAY[i][1]
        if ratio[i] < 0.1:
            filedir = "UI/Color-0/"
        elif ratio[i] < 0.25:
            filedir = "UI/Color-25/"
        elif ratio[i] < 0.5:
            filedir = "UI/Color-50/"
        elif ratio[i] < 0.75:
            filedir = "UI/Color-75/"
        elif ratio[i] < 1.0:
            filedir = "UI/Color-100/"
        else:
            filedir = "UI/Color-Ov100/"
        if i < 6:
          _bar_image = pygame.image.load(filedir + "Pie60.png")
        elif i >= 6 and i < 12:
          _bar_image = pygame.image.load(filedir + "Pie60L.png")
        elif i >= 12 and i < 16:
          _bar_image = pygame.image.load(filedir + "Pie45.png")
        else:
          _bar_image = pygame.image.load(filedir + "Circle.png")

        roto_image = pygame.transform.rotate(_bar_image, theta(i))
        screen.blit(roto_image, (PX + _dx, PY + _dy))
        screen.blit(pygame.image.load("UI/圆环轨迹.png"), (PX-56, PY-4))

def theta(index):
    index += 1
    if index == 17:
        return 0
    elif index >= 1 and index <= 6:
        return (index-1) * 60
    elif index >= 7 and index <= 12:
        return (index-1)*60
    elif index >= 13 and index <=16:
        return (index-1)*90

def generate_ave_by_text(string,data,screen,patient_temp=False):
    _tmp_array = []
    if patient_temp:
      for d in data:
        if string in d.conclusion_text:
            _tmp_array.append(d.wall_array)
      if _tmp_array:
        _tmp_array_ave = [sts.mean(np.array(_tmp_array).T[i]) for i in range(0, 17)]
        _tmp_array_med = [sts.median(np.array(_tmp_array).T[i]) for i in range(0, 17)]
      else:
        return print("筛选失败，请检查字段是否输入正确。")
    else:
      _tmp_array_ave = data
      _tmp_array_med = data
    clear_figure(screen)
    draw_figure(_tmp_array_ave, screen , 80 , 10)
    draw_figure(_tmp_array_med, screen, 400, 10)
    draw_note(screen)
    output(screen, string)
       # fg.draw_figure(fat_means, screen)

def output(screen,title):
    f = pygame.font.Font('C:/Windows/Fonts/simhei.ttf', 26)
    text = f.render(title, True, (255,255,255), (0, 0, 0))
    screen.blit(text,(59,231))
    pygame.image.save(screen,"output/" + title+".png")
