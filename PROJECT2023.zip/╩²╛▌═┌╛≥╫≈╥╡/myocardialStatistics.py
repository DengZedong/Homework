import scipy.stats as stats
import numpy as np


def find_median(nums):
    sorted_nums = np.sort(nums)
    median = np.median(sorted_nums)
    return median

def is_normal(data):
    # 使用stats.shapiro函数进行Shapiro-Wilk检验
    # 返回的结果是一个元组，第一个元素是检验结果的统计量，第二个元素是p-value
    statistic,p_value = stats.shapiro(data)

    # 设置显著性水平
    alpha = 0.05

    # 判断是否符合正态分布
    return p_value > alpha

#正常的平均值
def normal_average(data):
    array = []
    _ave_array = [0] * 17
    for d in data:
       if '未见明显异常' in d.conclusion_text:
           if len(d.wall_array) < 17:
               continue
           array.append(d.wall_array)
    #按列读取array
    columns = zip(*array)
    i = 0
    for c in columns:
        _sum = 0
        if is_normal(list(c)):
            print("数据符合正态分布，将取平均值作为标准值。")
            _ave_array[i] = sum(c)*1.0/len(array)
        else:
            print("数据不符合正态分布，将取中位数作为标准值。")
            _ave_array[i] = find_median(c)
        i+=1
    return _ave_array

def diff_array(normal_array,data):
    array = []
    for d in data:
        _array = [0] * 17
        for i in range(0,17):
            _array[i] = abs(d.wall_array[i] - normal_array[i])
        array.append(_array)
    return array


