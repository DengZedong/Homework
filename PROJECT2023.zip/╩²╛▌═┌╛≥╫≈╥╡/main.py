import getText
import figure as fg
import pygame
import SKlearn
import random
import numpy as np
import matplotlib.pyplot as plt

if __name__ == '__main__':
    #-----------------------------读取心脏报告-----------------------------------------------------
    data = getText.listlize("Reports/1_22年心脏报告pros.xlsx",False)
    data = data + getText.listlize("Reports/2021心脏报告.xlsx",False)
    data = data + getText.listlize("Reports/2020心脏报告.xlsx",True)
    # -------------------------------------------------------------------------------------------
    # pygame初始化
    pygame.init()
    # 设置主屏窗口
    screen = pygame.display.set_mode((570,290))
    # 设置窗口的标题
    pygame.display.set_caption('邓泽东')
    #-----------------------------根据KeyWord生成心肌增厚图------------------------------------------
    fg.generate_ave_by_text("[测试用例]",[7,9,13,20,7,9,13,20,7,9,13,20,7,9,13,20,3],screen,False)
    fg.generate_ave_by_text('肥厚型心肌病',data, screen,True)
    fg.generate_ave_by_text('高血压', data, screen, True)
    fg.generate_ave_by_text('心肌淀粉样变', data, screen, True)
    fg.generate_ave_by_text('未见明显异常', data, screen, True)
    fg.generate_ave_by_text('缺血', data, screen, True)
    fg.generate_ave_by_text('纤维化', data, screen, True)
    fg.generate_ave_by_text('心肌梗死', data, screen, True)
    # --------------------------------------训练模型进行二分类---------------------------------------
    _temp = True
    _x_array = []
    _y_array = []
    _x_array_verify = []
    _y_array_verify = []
    _sk_data = []
    _temp_data = []
    _temp_data = np.array([d.wall_array for d in data])
    _temp_data = _temp_data.T
    _means_array = [np.mean(d) for d in _temp_data]
    _stds_array = [np.std(d) for d in _temp_data]
    #数据标准化
    _temp_data = [(_temp_data[i] -  _means_array[i])/_stds_array[i] for i in range(0,len(_temp_data))]
    #数据归一化
    _temp_data = [(_temp_data[i] - min(_means_array)) /((max(_means_array)) - min(_means_array))for i in range(0, len(_temp_data))]
    _temp_data = np.array(_temp_data).T
    for i in range(0,len(data)):
        if '肥厚型心肌病' in data[i].conclusion_text:
            _sk_data.append([_temp_data[i],0])
        elif '高血压' in data[i].conclusion_text:
            _sk_data.append([_temp_data[i],1])

    _slice_temp = int(len(_sk_data)*0.7)
    random.shuffle(_sk_data)
    data_train = _sk_data[:_slice_temp]
    data_verify = _sk_data[(_slice_temp-len(_sk_data)):]
    for i in range(0,len(data_train)):
      _x_array.append(data_train[i][0])
      _y_array.append(data_train[i][1])
    for i in range(0, len(data_verify)):
      _x_array_verify.append(data_verify[i][0])
      _y_array_verify.append(data_verify[i][1])

    print("训练集数据量：" + str(len(_x_array)))
    print("测试集数据量：" + str(len(_x_array_verify)))
    #训练并输出结果
    outvalues = [SKlearn.Logistic_train(_x_array, _y_array, _x_array_verify, _y_array_verify),
    SKlearn.SVM_train(_x_array,_y_array,_x_array_verify,_y_array_verify),
    SKlearn.KNN_train(_x_array,_y_array,_x_array_verify,_y_array_verify),
    SKlearn.RandomForest_train(_x_array,_y_array,_x_array_verify,_y_array_verify),
    SKlearn.NB_train(_x_array, _y_array, _x_array_verify, _y_array_verify),]

    #绘制结果的条形图

    for i in range(0,5):
      #绘制结果的条形图
      # 数据
      categories = ('Logistic', 'SVM', 'KNN', 'RandomForest', 'Nor-Bays')
      # 创建子图
      fig, ax = plt.subplots()

      # 绘制柱状图
      colors = ['#c96800','#fe9900','#fecc01','#feff98','#c96800']
      values =np.array(outvalues).T[i]
      ax.bar(categories,values,color=colors)

      # 更改标题
      ax.set_title(['Accuracy','AUC','F1-Score','Recall'][i])

      # 设置标题和标签
      ax.set_xlabel('Categories')
      ax.set_ylabel('Values')
      for i in range(len(categories)):
          ax.text(i, values[i] + 0.01, str(round(values[i],2)), ha='center',color='black')
      # 显示图形
      plt.show()


