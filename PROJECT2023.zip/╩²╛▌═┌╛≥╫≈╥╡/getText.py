import pandas as pd
import patient
import copy


def read_data(data_name):
    return pd.read_excel(data_name)

def read_by_row(index,data):
    return data.loc[index]

def listlize(file_name,old_temp):
    data = read_data(file_name)
  #  print(data)
    array = []
    count_a = 0
    count_b = 0
    for i in range(0,len(data)):
        pat = patient.patient()
        pat.invalid_temp = False
        try:
            pat.process_report(read_by_row(i,data),old_temp)
        except:
            pat.invalid_temp = True #无法处理的数据，标记为无效

        if(pat.invalid_temp):
            print(str(pat.name) + '(' +str(pat.id) + ')' + ":无法提取")
            count_a += 1
        else:
            print(str(pat.name) + '(' +str(pat.id) + ')' +  ":提取完成")
          #  print(pat.wall_array)
            count_b += 1
            new_pat = copy.deepcopy(pat)
            array.append(new_pat)
    print("----------------------------------")
    print("数据集名称:" + file_name)
    print("数据总数:" + str(count_a + count_b))
    print("无法提取:" + str(count_a))
    print("提取完成:" + str(count_b))
    print("----------------------------------")

    return array
